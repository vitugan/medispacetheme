<?php
/**
 * Main Plugin Loader Class.
 *
 * Wires all subsystems together via WordPress action hooks.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Plugin
 *
 * Core loader responsible for instantiating and hooking all plugin subsystems.
 */
class Plugin {

	/**
	 * Cached plugin settings.
	 *
	 * @var array
	 */
	private array $settings;

	/**
	 * Plugin constructor.
	 *
	 * Registers all action hooks.
	 */
	public function __construct() {
		$this->settings = $this->get_settings();

		new Customizer();

		add_action( 'init', array( $this, 'register_post_types' ), 10 );
		add_action( 'init', array( $this, 'register_meta_boxes' ), 20 );
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

		if ( ! empty( $this->settings['enable_blocks'] ) ) {
			add_action( 'init', array( $this, 'register_blocks' ), 5 );
		}
	}

	/**
	 * Retrieves the plugin settings option with a default fallback.
	 *
	 * @return array
	 */
	private function get_settings(): array {
		$defaults = array(
			'enable_services' => 1,
			'enable_projects' => 1,
			'enable_team'     => 0,
			'enable_faq'      => 0,
			'enable_rest'     => 1,
			'enable_blocks'   => 1,
		);

		$saved = get_option( 'msc_settings', array() );

		return wp_parse_args( $saved, $defaults );
	}

	/**
	 * Registers Custom Post Types and their taxonomies.
	 *
	 * Each CPT is gated behind its corresponding settings toggle.
	 *
	 * @return void
	 */
	public function register_post_types(): void {
		if ( ! empty( $this->settings['enable_services'] ) ) {
			( new CPT\Services() )->register();
			( new Taxonomies\ServiceCategory() )->register();
		}

		if ( ! empty( $this->settings['enable_projects'] ) ) {
			( new CPT\Projects() )->register();
			( new Taxonomies\ProjectCategory() )->register();
		}
	}

	/**
	 * Registers meta boxes for active CPTs.
	 *
	 * @return void
	 */
	public function register_meta_boxes(): void {
		if ( ! empty( $this->settings['enable_services'] ) ) {
			new Meta\Services();
		}

		if ( ! empty( $this->settings['enable_projects'] ) ) {
			new Meta\Projects();
		}
	}

	/**
	 * Delegates admin menu registration to the Settings class.
	 *
	 * @return void
	 */
	public function register_admin_menu(): void {
		( new Settings() )->register_menu();
	}

	/**
	 * Delegates admin asset enqueueing to the Settings class.
	 *
	 * @param string $hook_suffix The current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_admin_assets( string $hook_suffix ): void {
		( new Settings() )->enqueue_assets( $hook_suffix );
	}

	/**
	 * Delegates REST route registration to the Settings class.
	 *
	 * @return void
	 */
	public function register_rest_routes(): void {
		( new Settings() )->register_rest_routes();
	}

	/**
	 * Delegates block registration to the Blocks class.
	 *
	 * @return void
	 */
	public function register_blocks(): void {
		( new Blocks() )->register();
	}
}
