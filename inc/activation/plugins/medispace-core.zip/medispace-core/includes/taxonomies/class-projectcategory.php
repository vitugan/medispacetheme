<?php
/**
 * Project Category Taxonomy.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore\Taxonomies;

if (!defined("ABSPATH")) {
    exit();
}

/**
 * Class ProjectCategory
 *
 * Registers the msc_project_cat hierarchical taxonomy for Projects.
 */
class ProjectCategory
{
    /**
     * The taxonomy key.
     *
     * @var string
     */
    const TAXONOMY = "msc_project_cat";

    /**
     * Registers the taxonomy with WordPress.
     *
     * @return void
     */
    public function register(): void
    {
        $labels = [
            "name" => esc_html_x(
                "Project Categories",
                "taxonomy general name",
                "medispace-core",
            ),
            "singular_name" => esc_html_x(
                "Project Category",
                "taxonomy singular name",
                "medispace-core",
            ),
            "search_items" => esc_html__(
                "Search Project Categories",
                "medispace-core",
            ),
            "all_items" => esc_html__(
                "All Project Categories",
                "medispace-core",
            ),
            "parent_item" => esc_html__(
                "Parent Project Category",
                "medispace-core",
            ),
            "parent_item_colon" => esc_html__(
                "Parent Project Category:",
                "medispace-core",
            ),
            "edit_item" => esc_html__(
                "Edit Project Category",
                "medispace-core",
            ),
            "update_item" => esc_html__(
                "Update Project Category",
                "medispace-core",
            ),
            "add_new_item" => esc_html__(
                "Add New Project Category",
                "medispace-core",
            ),
            "new_item_name" => esc_html__(
                "New Project Category Name",
                "medispace-core",
            ),
            "menu_name" => esc_html__("Categories", "medispace-core"),
        ];

        $args = [
            "hierarchical" => true,
            "labels" => $labels,
            "show_ui" => true,
            "show_admin_column" => true,
            "query_var" => true,
            "rewrite" => ["slug" => "project-category"],
            "show_in_rest" => true,
            "rest_base" => "project-categories",
        ];

        register_taxonomy(self::TAXONOMY, ["project"], $args);
    }
}
