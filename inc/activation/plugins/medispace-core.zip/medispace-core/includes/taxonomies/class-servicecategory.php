<?php
/**
 * Service Category Taxonomy.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore\Taxonomies;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class ServiceCategory
 *
 * Registers the msc_service_cat hierarchical taxonomy for Services.
 */
class ServiceCategory {

	/**
	 * The taxonomy key.
	 *
	 * @var string
	 */
	const TAXONOMY = 'msc_service_cat';

	/**
	 * Registers the taxonomy with WordPress.
	 *
	 * @return void
	 */
	public function register(): void {
		$labels = array(
			'name'              => esc_html_x( 'Service Categories', 'taxonomy general name', 'medispace-core' ),
			'singular_name'     => esc_html_x( 'Service Category', 'taxonomy singular name', 'medispace-core' ),
			'search_items'      => esc_html__( 'Search Service Categories', 'medispace-core' ),
			'all_items'         => esc_html__( 'All Service Categories', 'medispace-core' ),
			'parent_item'       => esc_html__( 'Parent Service Category', 'medispace-core' ),
			'parent_item_colon' => esc_html__( 'Parent Service Category:', 'medispace-core' ),
			'edit_item'         => esc_html__( 'Edit Service Category', 'medispace-core' ),
			'update_item'       => esc_html__( 'Update Service Category', 'medispace-core' ),
			'add_new_item'      => esc_html__( 'Add New Service Category', 'medispace-core' ),
			'new_item_name'     => esc_html__( 'New Service Category Name', 'medispace-core' ),
			'menu_name'         => esc_html__( 'Categories', 'medispace-core' ),
		);

		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'service-category' ),
			'show_in_rest'      => true,
			'rest_base'         => 'service-categories',
		);

		register_taxonomy( self::TAXONOMY, array( 'msc_service' ), $args );
	}
}
