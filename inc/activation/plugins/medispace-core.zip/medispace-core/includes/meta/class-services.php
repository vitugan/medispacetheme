<?php
/**
 * Services Meta Box.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore\Meta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Services
 *
 * Registers and handles the "Service Details" meta box for the msc_service post type.
 */
class Services {

	/**
	 * Nonce action identifier.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'msc_save_service_meta';

	/**
	 * Nonce field name.
	 *
	 * @var string
	 */
	const NONCE_FIELD = 'msc_service_meta_nonce';

	/**
	 * Services constructor.
	 *
	 * Hooks meta box registration and save callback.
	 */
	public function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_msc_service', array( $this, 'save_meta' ), 10, 2 );
	}

	/**
	 * Registers the Service Details meta box.
	 *
	 * @return void
	 */
	public function add_meta_boxes(): void {
		add_meta_box(
			'msc_service_details',
			esc_html__( 'Service Details', 'medispace-core' ),
			array( $this, 'render' ),
			'msc_service',
			'normal',
			'high'
		);
	}

	/**
	 * Renders the meta box HTML.
	 *
	 * @param \WP_Post $post The current post object.
	 * @return void
	 */
	public function render( \WP_Post $post ): void {
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );

		$icon       = get_post_meta( $post->ID, '_msc_service_icon', true );
		$short_desc = get_post_meta( $post->ID, '_msc_service_short_desc', true );
		$cta_url    = get_post_meta( $post->ID, '_msc_service_cta_url', true );
		?>
		<table class="form-table">
			<tr>
				<th scope="row">
					<label for="msc_service_icon"><?php esc_html_e( 'Icon Class', 'medispace-core' ); ?></label>
				</th>
				<td>
					<input
						type="text"
						id="msc_service_icon"
						name="msc_service_icon"
						value="<?php echo esc_attr( $icon ); ?>"
						class="regular-text"
						placeholder="<?php esc_attr_e( 'e.g. dashicons-hammer', 'medispace-core' ); ?>"
					/>
					<p class="description"><?php esc_html_e( 'Enter a dashicon class or custom icon class.', 'medispace-core' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="msc_service_short_desc"><?php esc_html_e( 'Short Description', 'medispace-core' ); ?></label>
				</th>
				<td>
					<textarea
						id="msc_service_short_desc"
						name="msc_service_short_desc"
						rows="4"
						class="large-text"
					><?php echo esc_textarea( $short_desc ); ?></textarea>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="msc_service_cta_url"><?php esc_html_e( 'CTA URL', 'medispace-core' ); ?></label>
				</th>
				<td>
					<input
						type="url"
						id="msc_service_cta_url"
						name="msc_service_cta_url"
						value="<?php echo esc_url( $cta_url ); ?>"
						class="regular-text"
					/>
					<p class="description"><?php esc_html_e( 'Call-to-action link for this service.', 'medispace-core' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Saves the meta box data on post save.
	 *
	 * @param int      $post_id The post ID being saved.
	 * @param \WP_Post $post    The post object.
	 * @return void
	 */
	public function save_meta( int $post_id, \WP_Post $post ): void {
		// Verify nonce.
		if (
			! isset( $_POST[ self::NONCE_FIELD ] ) ||
			! wp_verify_nonce( sanitize_key( $_POST[ self::NONCE_FIELD ] ), self::NONCE_ACTION )
		) {
			return;
		}

		// Skip autosaves and revisions.
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		// Verify capability.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( isset( $_POST['msc_service_icon'] ) ) {
			update_post_meta( $post_id, '_msc_service_icon', sanitize_text_field( wp_unslash( $_POST['msc_service_icon'] ) ) );
		}

		if ( isset( $_POST['msc_service_short_desc'] ) ) {
			update_post_meta( $post_id, '_msc_service_short_desc', sanitize_textarea_field( wp_unslash( $_POST['msc_service_short_desc'] ) ) );
		}

		if ( isset( $_POST['msc_service_cta_url'] ) ) {
			update_post_meta( $post_id, '_msc_service_cta_url', esc_url_raw( wp_unslash( $_POST['msc_service_cta_url'] ) ) );
		}
	}
}
