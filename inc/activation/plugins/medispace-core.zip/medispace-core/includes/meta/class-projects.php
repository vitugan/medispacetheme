<?php
/**
 * Projects Meta Box.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore\Meta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Projects
 *
 * Registers and handles the "Project Details" meta box for the msc_project post type.
 */
class Projects {

	/**
	 * Nonce action identifier.
	 *
	 * @var string
	 */
	const NONCE_ACTION = 'msc_save_project_meta';

	/**
	 * Nonce field name.
	 *
	 * @var string
	 */
	const NONCE_FIELD = 'msc_project_meta_nonce';

	/**
	 * Projects constructor.
	 *
	 * Hooks meta box registration and save callback.
	 */
	public function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post_msc_project', array( $this, 'save_meta' ), 10, 2 );
	}

	/**
	 * Registers the Project Details meta box.
	 *
	 * @return void
	 */
	public function add_meta_boxes(): void {
		add_meta_box(
			'msc_project_details',
			esc_html__( 'Project Details', 'medispace-core' ),
			array( $this, 'render' ),
			'msc_project',
			'normal',
			'high'
		);
	}

	/**
	 * Renders the meta box HTML.
	 *
	 * @param \WP_Post $post The current post object.
	 * @return void
	 */
	public function render( \WP_Post $post ): void {
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );

		$client = get_post_meta( $post->ID, '_msc_project_client', true );
		$url    = get_post_meta( $post->ID, '_msc_project_url', true );
		$year   = get_post_meta( $post->ID, '_msc_project_year', true );
		$tags   = get_post_meta( $post->ID, '_msc_project_tags', true );
		?>
		<table class="form-table">
			<tr>
				<th scope="row">
					<label for="msc_project_client"><?php esc_html_e( 'Client Name', 'medispace-core' ); ?></label>
				</th>
				<td>
					<input
						type="text"
						id="msc_project_client"
						name="msc_project_client"
						value="<?php echo esc_attr( $client ); ?>"
						class="regular-text"
					/>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="msc_project_url"><?php esc_html_e( 'Project URL', 'medispace-core' ); ?></label>
				</th>
				<td>
					<input
						type="url"
						id="msc_project_url"
						name="msc_project_url"
						value="<?php echo esc_url( $url ); ?>"
						class="regular-text"
					/>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="msc_project_year"><?php esc_html_e( 'Project Year', 'medispace-core' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						id="msc_project_year"
						name="msc_project_year"
						value="<?php echo esc_attr( $year ); ?>"
						class="small-text"
						min="1900"
						max="<?php echo esc_attr( (string) ( gmdate( 'Y' ) + 5 ) ); ?>"
					/>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="msc_project_tags"><?php esc_html_e( 'Tags', 'medispace-core' ); ?></label>
				</th>
				<td>
					<input
						type="text"
						id="msc_project_tags"
						name="msc_project_tags"
						value="<?php echo esc_attr( $tags ); ?>"
						class="regular-text"
						placeholder="<?php esc_attr_e( 'Comma-separated tags', 'medispace-core' ); ?>"
					/>
					<p class="description"><?php esc_html_e( 'Enter comma-separated technology or skill tags.', 'medispace-core' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Saves the meta box data on post save.
	 *
	 * @param int      $post_id The post ID being saved.
	 * @param \WP_Post $post    The post object.
	 * @return void
	 */
	public function save_meta( int $post_id, \WP_Post $post ): void {
		// Verify nonce.
		if (
			! isset( $_POST[ self::NONCE_FIELD ] ) ||
			! wp_verify_nonce( sanitize_key( $_POST[ self::NONCE_FIELD ] ), self::NONCE_ACTION )
		) {
			return;
		}

		// Skip autosaves and revisions.
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		// Verify capability.
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( isset( $_POST['msc_project_client'] ) ) {
			update_post_meta( $post_id, '_msc_project_client', sanitize_text_field( wp_unslash( $_POST['msc_project_client'] ) ) );
		}

		if ( isset( $_POST['msc_project_url'] ) ) {
			update_post_meta( $post_id, '_msc_project_url', esc_url_raw( wp_unslash( $_POST['msc_project_url'] ) ) );
		}

		if ( isset( $_POST['msc_project_year'] ) ) {
			update_post_meta( $post_id, '_msc_project_year', absint( $_POST['msc_project_year'] ) );
		}

		if ( isset( $_POST['msc_project_tags'] ) ) {
			update_post_meta( $post_id, '_msc_project_tags', sanitize_text_field( wp_unslash( $_POST['msc_project_tags'] ) ) );
		}
	}
}
