<?php
/**
 * Settings Class.
 *
 * Registers the admin settings page under the Appearance menu and
 * provides a REST API endpoint for reading and updating plugin settings.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Settings
 *
 * Handles admin menu registration, React bundle enqueueing,
 * and the custom REST API endpoint for plugin settings.
 */
class Settings {

	/**
	 * The REST API namespace.
	 *
	 * @var string
	 */
	const REST_NAMESPACE = 'medispace/v1';

	/**
	 * The admin menu slug.
	 *
	 * @var string
	 */
	const MENU_SLUG = 'medispace-settings';

	/**
	 * Registers the settings page under the Appearance menu.
	 *
	 * @return void
	 */
	public function register_menu(): void {
		add_theme_page(
			esc_html__( 'MediSpace Settings', 'medispace-core' ),
			esc_html__( 'MediSpace', 'medispace-core' ),
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Renders the admin page shell.
	 *
	 * The React application mounts into the #medispace-admin-root element.
	 *
	 * @return void
	 */
	public function render_page(): void {
		echo '<div id="medispace-admin-root"></div>';
	}

	/**
	 * Enqueues the React admin bundle on the settings page.
	 *
	 * @param string $hook_suffix The current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_assets( string $hook_suffix ): void {
		if ( 'appearance_page_' . self::MENU_SLUG !== $hook_suffix ) {
			return;
		}

		$asset_file = MSC_PLUGIN_DIR . 'assets/build/admin.asset.php';
		$asset      = file_exists( $asset_file )
			? require $asset_file
			: array(
				'dependencies' => array( 'wp-element', 'wp-components', 'wp-api-fetch', 'wp-i18n' ),
				'version'      => MSC_VERSION,
			);

		wp_enqueue_script(
			'medispace-admin',
			MSC_PLUGIN_URL . 'assets/admin/index.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);

		if ( file_exists( MSC_PLUGIN_DIR . 'assets/admin/index.css' ) ) {
			wp_enqueue_style(
				'medispace-admin',
				MSC_PLUGIN_URL . 'assets/admin/index.css',
				array( 'wp-components' ),
				$asset['version']
			);
		}

		// if ( file_exists( MSC_PLUGIN_DIR . 'assets/admin/index-rtl.css' ) ) {
		// 	wp_enqueue_style(
		// 		'medispace-admin-rtl',
		// 		MSC_PLUGIN_URL . 'assets/admin/index-rtl.css',
		// 		array( 'wp-components' ),
		// 		$asset['version']
		// 	);
		// }

		wp_localize_script(
			'medispace-admin',
			'medispaceAdmin',
			array(
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'root'     => esc_url_raw( rest_url() ),
				'settings' => $this->get_settings(),
			)
		);
	}

	/**
	 * Registers REST API routes for settings management.
	 *
	 * @return void
	 */
	public function register_rest_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/settings',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'rest_get_settings' ),
					'permission_callback' => array( $this, 'rest_permission_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'rest_update_settings' ),
					'permission_callback' => array( $this, 'rest_permission_check' ),
					'args'                => $this->get_rest_args(),
				),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/site-identity',
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_get_site_identity' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * REST permission callback вЂ” requires manage_options capability.
	 *
	 * @return bool|\WP_Error
	 */
	public function rest_permission_check(): bool|\WP_Error {
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'rest_forbidden',
				esc_html__( 'You do not have permission to manage plugin settings.', 'medispace-core' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * REST GET handler вЂ” returns current settings.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_get_settings(): \WP_REST_Response {
		return new \WP_REST_Response( $this->get_settings(), 200 );
	}

	/**
	 * REST POST handler вЂ” validates and persists new settings.
	 *
	 * @param \WP_REST_Request $request The REST request object.
	 * @return \WP_REST_Response
	 */
	public function rest_update_settings( \WP_REST_Request $request ): \WP_REST_Response {
		$params = $request->get_json_params();

		$updated = array(
			'enable_services' => absint( $params['enable_services'] ?? 0 ),
			'enable_projects' => absint( $params['enable_projects'] ?? 0 ),
			'enable_team'     => absint( $params['enable_team'] ?? 0 ),
			'enable_faq'      => absint( $params['enable_faq'] ?? 0 ),
			'enable_rest'     => absint( $params['enable_rest'] ?? 0 ),
			'enable_blocks'   => absint( $params['enable_blocks'] ?? 0 ),
		);

		update_option( 'msc_settings', $updated );

		// Flush rewrite rules so CPT slugs update immediately.
		flush_rewrite_rules();

		return new \WP_REST_Response( $updated, 200 );
	}

	/**
	 * Returns argument schema for the REST POST endpoint.
	 *
	 * @return array
	 */
	private function get_rest_args(): array {
		$toggle_schema = array(
			'type'    => 'integer',
			'enum'    => array( 0, 1 ),
			'default' => 0,
		);

		return array(
			'enable_services' => $toggle_schema,
			'enable_projects' => $toggle_schema,
			'enable_team'     => $toggle_schema,
			'enable_faq'      => $toggle_schema,
			'enable_rest'     => $toggle_schema,
			'enable_blocks'   => $toggle_schema,
		);
	}

	/**
	 * Retrieves plugin settings with defaults.
	 *
	 * @return array
	 */
	private function get_settings(): array {
		$defaults = array(
			'enable_services' => 1,
			'enable_projects' => 1,
			'enable_team'     => 0,
			'enable_faq'      => 0,
			'enable_rest'     => 1,
			'enable_blocks'   => 1,
		);

		return wp_parse_args( get_option( 'msc_settings', array() ), $defaults );
	}

	/**
	 * REST GET handler — returns site identity and logo data.
	 *
	 * @return \WP_REST_Response
	 */
	public function rest_get_site_identity(): \WP_REST_Response {
		$site_logo_id = absint( get_theme_mod( 'custom_logo' ) );
		$site_logo    = $this->get_image_src( $site_logo_id );

		$site_icon_id = absint( get_option( 'site_icon' ) );
		$site_icon    = $this->get_image_src( $site_icon_id );

		$custom_logo_id = absint( get_theme_mod( 'msc_custom_logo_id' ) );
		$custom_logo    = $this->get_image_src( $custom_logo_id );

		return new \WP_REST_Response(
			array(
				'site_name'          => sanitize_text_field( get_bloginfo( 'name' ) ),
				'site_description'   => sanitize_text_field( get_bloginfo( 'description' ) ),
				'site_logo_id'       => $site_logo_id ?: null,
				'site_logo_url'      => $site_logo ? esc_url( $site_logo['url'] ) : null,
				'site_logo_width'    => $site_logo ? absint( $site_logo['width'] ) : null,
				'site_logo_height'   => $site_logo ? absint( $site_logo['height'] ) : null,
				'site_icon_id'       => $site_icon_id ?: null,
				'site_icon_url'      => $site_icon ? esc_url( $site_icon['url'] ) : null,
				'custom_logo_id'     => $custom_logo_id ?: null,
				'custom_logo_url'    => $custom_logo ? esc_url( $custom_logo['url'] ) : null,
				'custom_logo_width'  => absint( get_theme_mod( 'msc_custom_logo_width', 120 ) ),
				'custom_logo_link'   => (bool) get_theme_mod( 'msc_custom_logo_link', true ),
				'custom_logo_invert' => (bool) get_theme_mod( 'msc_custom_logo_invert', false ),
			),
			200
		);
	}

	/**
	 * Returns URL, width, and height for a given attachment ID, or null if invalid.
	 *
	 * @param int $id Attachment post ID.
	 * @return array{url: string, width: int, height: int}|null
	 */
	private function get_image_src( int $id ): ?array {
		if ( ! $id ) {
			return null;
		}

		$src = wp_get_attachment_image_src( $id, 'full' );

		if ( ! $src ) {
			return null;
		}

		return array(
			'url'    => $src[0],
			'width'  => $src[1],
			'height' => $src[2],
		);
	}
}
