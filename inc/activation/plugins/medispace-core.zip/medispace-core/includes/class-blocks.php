<?php
/**
 * Blocks Class.
 *
 * Auto-registers every compiled block found under assets/blocks/ by
 * passing its directory to register_block_type(), which reads block.json and
 * enqueues the declared scripts and styles automatically.
 *
 * Adding a new block requires no changes here вЂ” build the block, and this
 * class picks it up on the next page load.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore;

if (!defined("ABSPATH")) {
    exit();
}

/**
 * Class Blocks
 */
class Blocks
{
    public function __construct()
    {
        add_filter("block_categories_all", [$this, "register_category"], 10, 2);
        add_action("wp_enqueue_scripts", [$this, "register_libraries"]);
        add_action("enqueue_block_assets", [$this, "register_libraries"]);
    }

    /**
     * Registers Leaflet JS/CSS under the handles declared in block.json.
     *
     * @return void
     */
    public function register_libraries(): void
    {
        $lib_dir = MSC_PLUGIN_DIR . "assets/lib/leaflet/";
        $lib_url = MSC_PLUGIN_URL . "assets/lib/leaflet/";

        if ( ! wp_script_is( "lib-js-map-block-leaflet", "registered" ) ) {
            wp_register_script(
                "lib-js-map-block-leaflet",
                $lib_url . "leaflet.js",
                [],
                MSC_VERSION,
                true
            );
        }

        if ( ! wp_style_is( "lib-css-map-block-leaflet", "registered" ) ) {
            wp_register_style(
                "lib-css-map-block-leaflet",
                $lib_url . "leaflet.css",
                [],
                MSC_VERSION
            );
        }
    }
    /**
     * Registers all compiled blocks found in the build directory.
     *
     * @return void
     */
    public function register(): void
    {
        $blocks_dir = MSC_PLUGIN_DIR . "assets/blocks/";

        if (!is_dir($blocks_dir)) {
            return;
        }

        foreach (glob($blocks_dir . "*", GLOB_ONLYDIR) as $block_dir) {
            // error_log( print_r( $block_dir, true ) );
            register_block_type($block_dir);
        }
    }

    /**
     * Registers category for theme blocks.
     *
     * @return void
     */
    public function register_category($categories)
    {
        return array_merge(
            [
                [
                    "slug" => "medispace-theme-blocks",
                    "title" => "Medispace theme",
                    "icon" => null,
                ],
            ],
            $categories,
        );
    }
}
