<?php
/**
 * Services Custom Post Type.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore\CPT;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Services
 *
 * Registers the msc_service Custom Post Type.
 */
class Services {

	/**
	 * The post type key.
	 *
	 * @var string
	 */
	const POST_TYPE = 'msc_service';

	/**
	 * Registers the post type with WordPress.
	 *
	 * @return void
	 */
	public function register(): void {
		$labels = array(
			'name'                  => esc_html_x( 'Services', 'Post type general name', 'medispace-core' ),
			'singular_name'         => esc_html_x( 'Service', 'Post type singular name', 'medispace-core' ),
			'menu_name'             => esc_html_x( 'Services', 'Admin Menu text', 'medispace-core' ),
			'name_admin_bar'        => esc_html_x( 'Service', 'Add New on Toolbar', 'medispace-core' ),
			'add_new'               => esc_html__( 'Add New', 'medispace-core' ),
			'add_new_item'          => esc_html__( 'Add New Service', 'medispace-core' ),
			'new_item'              => esc_html__( 'New Service', 'medispace-core' ),
			'edit_item'             => esc_html__( 'Edit Service', 'medispace-core' ),
			'view_item'             => esc_html__( 'View Service', 'medispace-core' ),
			'all_items'             => esc_html__( 'All Services', 'medispace-core' ),
			'search_items'          => esc_html__( 'Search Services', 'medispace-core' ),
			'not_found'             => esc_html__( 'No services found.', 'medispace-core' ),
			'not_found_in_trash'    => esc_html__( 'No services found in Trash.', 'medispace-core' ),
			'featured_image'        => esc_html__( 'Service Image', 'medispace-core' ),
			'set_featured_image'    => esc_html__( 'Set service image', 'medispace-core' ),
			'remove_featured_image' => esc_html__( 'Remove service image', 'medispace-core' ),
			'use_featured_image'    => esc_html__( 'Use as service image', 'medispace-core' ),
			'archives'              => esc_html__( 'Service Archives', 'medispace-core' ),
			'insert_into_item'      => esc_html__( 'Insert into service', 'medispace-core' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to this service', 'medispace-core' ),
			'filter_items_list'     => esc_html__( 'Filter services list', 'medispace-core' ),
			'items_list_navigation' => esc_html__( 'Services list navigation', 'medispace-core' ),
			'items_list'            => esc_html__( 'Services list', 'medispace-core' ),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'services' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 25,
			'menu_icon'          => 'dashicons-hammer',
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'revisions' ),
			'show_in_rest'       => true,
			'rest_base'          => 'services',
			'template'           => array( array( 'medispace/services-list' ) ),
		);

		register_post_type( self::POST_TYPE, $args );
	}
}
