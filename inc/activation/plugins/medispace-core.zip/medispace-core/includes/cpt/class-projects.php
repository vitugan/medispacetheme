<?php
/**
 * Projects Custom Post Type.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore\CPT;

if (!defined("ABSPATH")) {
    exit();
}

/**
 * Class Projects
 *
 * Registers the msc_project Custom Post Type.
 */
class Projects
{
    /**
     * The post type key.
     *
     * @var string
     */
    const POST_TYPE = "project";

    /**
     * Registers the post type with WordPress.
     *
     * @return void
     */
    public function register(): void
    {
        $labels = [
            "name" => esc_html_x(
                "Projects",
                "Post type general name",
                "medispace-core",
            ),
            "singular_name" => esc_html_x(
                "Project",
                "Post type singular name",
                "medispace-core",
            ),
            "menu_name" => esc_html_x(
                "Projects",
                "Admin Menu text",
                "medispace-core",
            ),
            "name_admin_bar" => esc_html_x(
                "Project",
                "Add New on Toolbar",
                "medispace-core",
            ),
            "add_new" => esc_html__("Add New", "medispace-core"),
            "add_new_item" => esc_html__("Add New Project", "medispace-core"),
            "new_item" => esc_html__("New Project", "medispace-core"),
            "edit_item" => esc_html__("Edit Project", "medispace-core"),
            "view_item" => esc_html__("View Project", "medispace-core"),
            "all_items" => esc_html__("All Projects", "medispace-core"),
            "search_items" => esc_html__("Search Projects", "medispace-core"),
            "not_found" => esc_html__("No projects found.", "medispace-core"),
            "not_found_in_trash" => esc_html__(
                "No projects found in Trash.",
                "medispace-core",
            ),
            "featured_image" => esc_html__("Project Image", "medispace-core"),
            "set_featured_image" => esc_html__(
                "Set project image",
                "medispace-core",
            ),
            "remove_featured_image" => esc_html__(
                "Remove project image",
                "medispace-core",
            ),
            "use_featured_image" => esc_html__(
                "Use as project image",
                "medispace-core",
            ),
            "archives" => esc_html__("Project Archives", "medispace-core"),
            "insert_into_item" => esc_html__(
                "Insert into project",
                "medispace-core",
            ),
            "uploaded_to_this_item" => esc_html__(
                "Uploaded to this project",
                "medispace-core",
            ),
            "filter_items_list" => esc_html__(
                "Filter projects list",
                "medispace-core",
            ),
            "items_list_navigation" => esc_html__(
                "Projects list navigation",
                "medispace-core",
            ),
            "items_list" => esc_html__("Projects list", "medispace-core"),
        ];

        $args = [
            "labels" => $labels,
            "public" => true,
            "publicly_queryable" => true,
            "show_ui" => true,
            "show_in_menu" => true,
            "query_var" => true,
            "rewrite" => ["slug" => "projects"],
            "capability_type" => "post",
            "has_archive" => true,
            "hierarchical" => false,
            "menu_position" => 26,
            "menu_icon" => "dashicons-portfolio",
            "supports" => [
                "title",
                "editor",
                "thumbnail",
                "excerpt",
                "custom-fields",
                "revisions",
            ],
            "show_in_rest" => true,
            "rest_base" => "projects",
            // "template" => [["medispace/projects-grid"]],
        ];

        register_post_type(self::POST_TYPE, $args);
    }
}
