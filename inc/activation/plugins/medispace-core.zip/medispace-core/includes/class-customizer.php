<?php
/**
 * Customizer Class.
 *
 * Registers the "MediSpace Theme" Customizer panel with Header (Main/Sticky) and Footer Logo sections,
 * and exposes them via action hooks and shortcodes.
 *
 * @package MediSpaceCore
 */

namespace MediSpaceCore;

if (!defined("ABSPATH")) {
    exit();
}

/**
 * Class Customizer
 */
class Customizer
{
    /**
     * Registers Customizer and frontend hooks.
     */
    public function __construct()
    {
        add_action("customize_register", [$this, "register"]);
        add_action("init", [$this, "register_output_hooks"]);
    }

    /**
     * Registers the Customizer panel, sections, settings, and controls.
     *
     * @param \WP_Customize_Manager $wp_customize Customizer manager instance.
     * @return void
     */
    public function register(\WP_Customize_Manager $wp_customize): void
    {
        $wp_customize->add_panel("msc_theme_panel", [
            "title" => esc_html__("MediSpace Theme", "medispace-core"),
            "priority" => 160,
        ]);

        // ==========================================
        // SECTION: Header Logos (Main & Sticky)
        // ==========================================
        $wp_customize->add_section("msc_header_logos", [
            "title" => esc_html__("Header Logos", "medispace-core"),
            "panel" => "msc_theme_panel",
            "priority" => 5,
        ]);

        // Sticky Logo Setting
        $wp_customize->add_setting("msc_sticky_logo_id", [
            "default" => 0,
            "sanitize_callback" => "absint",
            "transport" => "refresh",
        ]);
        $wp_customize->add_control(
            new \WP_Customize_Media_Control(
                $wp_customize,
                "msc_sticky_logo_id",
                [
                    "label" => esc_html__(
                        "Sticky Header Logo",
                        "medispace-core",
                    ),
                    "description" => esc_html__(
                        "Logo displayed when the header becomes sticky (scrolled state).",
                        "medispace-core",
                    ),
                    "section" => "msc_header_logos",
                    "mime_type" => "image",
                ],
            ),
        );

        // Sticky Logo Width Setting
        $wp_customize->add_setting("msc_sticky_logo_width", [
            "default" => 128,
            "sanitize_callback" => "absint",
            "transport" => "refresh",
        ]);
        $wp_customize->add_control("msc_sticky_logo_width", [
            "label" => esc_html__("Sticky Logo Width (px)", "medispace-core"),
            "section" => "msc_header_logos",
            "type" => "number",
            "input_attrs" => [
                "min" => 1,
                "step" => 1,
            ],
        ]);

        // ==========================================
        // SECTION: Footer Logo
        // ==========================================
        $wp_customize->add_section("msc_custom_logo", [
            "title" => esc_html__("Footer Logo", "medispace-core"),
            "panel" => "msc_theme_panel",
            "priority" => 10,
        ]);

        $wp_customize->add_setting("msc_custom_logo_id", [
            "default" => 0,
            "sanitize_callback" => "absint",
            "transport" => "refresh",
        ]);
        $wp_customize->add_control(
            new \WP_Customize_Media_Control(
                $wp_customize,
                "msc_custom_logo_id",
                [
                    "label" => esc_html__("Footer Logo", "medispace-core"),
                    "section" => "msc_custom_logo",
                    "mime_type" => "image",
                ],
            ),
        );

        $wp_customize->add_setting("msc_custom_logo_width", [
            "default" => 120,
            "sanitize_callback" => "absint",
            "transport" => "refresh",
        ]);
        $wp_customize->add_control("msc_custom_logo_width", [
            "label" => esc_html__("Width (px)", "medispace-core"),
            "section" => "msc_custom_logo",
            "type" => "number",
            "input_attrs" => [
                "min" => 1,
                "step" => 1,
            ],
        ]);

        $wp_customize->add_setting("msc_custom_logo_link", [
            "default" => true,
            "sanitize_callback" => [$this, "sanitize_checkbox"],
            "transport" => "refresh",
        ]);
        $wp_customize->add_control("msc_custom_logo_link", [
            "label" => esc_html__("Wrap in home link", "medispace-core"),
            "section" => "msc_custom_logo",
            "type" => "checkbox",
        ]);

        $wp_customize->add_setting("msc_custom_logo_invert", [
            "default" => false,
            "sanitize_callback" => [$this, "sanitize_checkbox"],
            "transport" => "refresh",
        ]);
        $wp_customize->add_control("msc_custom_logo_invert", [
            "label" => esc_html__(
                "Invert color (for dark backgrounds)",
                "medispace-core",
            ),
            "section" => "msc_custom_logo",
            "type" => "checkbox",
        ]);
    }

    /**
     * Registers the action hook listener and the shortcode on init.
     *
     * @return void
     */
    public function register_output_hooks(): void
    {
        add_action("msc_custom_logo", [$this, "render"]);
        add_shortcode("msc_custom_logo", [$this, "shortcode"]);
    }

    /**
     * Shortcode callback — captures render() output and returns it.
     *
     * @return string
     */
    public function shortcode(): string
    {
        ob_start();
        $this->render();
        return (string) ob_get_clean();
    }

    /**
     * Echoes the footer logo HTML.
     *
     * Outputs nothing when no logo attachment ID is saved.
     *
     * @return void
     */
    public function render(): void
    {
        $logo_id = absint(get_theme_mod("msc_custom_logo_id", 0));

        if (!$logo_id) {
            return;
        }

        $width = absint(get_theme_mod("msc_custom_logo_width", 120));
        $link = (bool) get_theme_mod("msc_custom_logo_link", true);
        $invert = (bool) get_theme_mod("msc_custom_logo_invert", false);

        $style = "max-width:" . $width . "px;";
        if ($invert) {
            $style .= "filter:invert(1);";
        }

        $img = wp_get_attachment_image($logo_id, "full", false, [
            "style" => $style,
        ]);

        if (!$img) {
            return;
        }

        if ($link) {
            printf(
                '<a href="%s">%s</a>',
                esc_url(home_url("/")),
                $img, // wp_get_attachment_image output is already escaped.
            );
        } else {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_get_attachment_image is safe.
            echo $img;
        }
    }

    /**
     * Sanitizes a Customizer checkbox value to boolean.
     *
     * @param mixed $value Raw Customizer value.
     * @return bool
     */
    public function sanitize_checkbox($value): bool
    {
        return (bool) $value;
    }
}
