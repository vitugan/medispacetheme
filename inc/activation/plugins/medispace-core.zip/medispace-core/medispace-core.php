<?php
/**
 * Plugin Name:       MediSpace Core
 * Plugin URI:        http://ecdevstudio.com/
 * Description:       Core functionality for the MediSpace theme: Custom Post Types, taxonomies, meta boxes, REST API, Gutenberg blocks, and admin settings.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            EcDev Studio
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       medispace-core
 *
 * @package MediSpaceCore
 */

if (!defined("ABSPATH")) {
    exit();
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

define("MSC_VERSION", "1.0.0");
define("MSC_PLUGIN_DIR", plugin_dir_path(__FILE__));
define("MSC_PLUGIN_URL", plugin_dir_url(__FILE__));

// ---------------------------------------------------------------------------
// SPL Autoloader
// ---------------------------------------------------------------------------

spl_autoload_register(function (string $class): void {
    $prefix = "MediSpaceCore\\";
    $len = strlen($prefix);

    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative = substr($class, $len);
    $parts = explode("\\", $relative);
    $filename = "class-" . strtolower(array_pop($parts)) . ".php";

    $path = MSC_PLUGIN_DIR . "includes/";
    if (!empty($parts)) {
        $path .= strtolower(implode("/", $parts)) . "/";
    }
    $path .= $filename;
    if (file_exists($path)) {
        require $path;
    }
});

// ---------------------------------------------------------------------------
// Activation / Deactivation Hooks
// ---------------------------------------------------------------------------

register_activation_hook(__FILE__, function (): void {
    $defaults = [
        "enable_services" => 1,
        "enable_projects" => 1,
        "enable_team" => 0,
        "enable_faq" => 0,
        "enable_rest" => 1,
        "enable_blocks" => 1,
    ];

    if (false === get_option("msc_settings")) {
        add_option("msc_settings", $defaults);
    }

    flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, function (): void {
    flush_rewrite_rules();
});

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------

add_action("plugins_loaded", function (): void {
    new MediSpaceCore\Plugin();
});
