<?php
/**
 * Render template for the custom container block.
 *
 * @var array    $attributes The block attributes.
 * @var string   $content    The saved content of InnerBlocks.
 * @var WP_Block $block      The block instance.
 */

$id = uniqid("lmb_");
$marker_content = trim(
    preg_replace("/\s\s+/", " ", $attributes["markerContent"]),
);

$classes = "cover-map__background";
if (array_key_exists("align", $attributes)) {
    switch ($attributes["align"]) {
        case "wide":
            $classes .= " alignwide";
            break;
        case "full":
            $classes .= " alignfull";
            break;
    }
}
?>

<div <?php echo get_block_wrapper_attributes([
    "style" =>
        "position:relative;--cover-map-height:" . absint($attributes["height"]) . "px;height:var(--cover-map-height)",
]); ?>>
	<div id="<?= $id ?>" class="<?= $classes ?>"></div>
	<div class="cover-map__content">
	    <div class="wp-block-group alignwide" style="margin-left:auto;margin-right:auto;max-width:var(--theme-content-width);">
    		<?= $content ?>
    	</div>
	</div>

	<script>
		( function(){
			function initilize() {
				const map = L.map( '<?= $id ?>', {
					dragging:        false,
					touchZoom:       false,
					scrollWheelZoom: false,
					doubleClickZoom: false,
					boxZoom:         false,
					keyboard:        false,
					zoomControl:     false,
					tap:             false,
				} ).setView( [ <?= $attributes["lat"] ?>, <?= $attributes[
    "lng"
] ?> ], <?= $attributes["zoom"] ?> );

				L.tileLayer( '<?= esc_js($attributes["themeUrl"]) ?>', {
					attribution: '<?= $attributes["themeAttribution"] ?>'
				} ).addTo( map );

				<?php if (isset($attributes["markerImage"])) { ?>
				const iconWidth  = <?= $attributes["markerSize"] ?>;
				const iconHeight = <?= ($attributes["markerImage"]["height"] /
        $attributes["markerImage"]["width"]) *
        $attributes["markerSize"] ?>;

				const icon = L.icon( {
					iconUrl:     '<?= esc_url($attributes["markerImage"]["url"]) ?>',
					iconSize:    [ iconWidth, iconHeight ],
					iconAnchor:  [ iconWidth / 2, iconHeight ],
					popupAnchor: [ 0, -iconHeight / 1.25 ],
				} );
				<?php } else { ?>
				const icon = new L.Icon.Default();
				<?php } ?>

				<?php if (!empty($marker_content)) { ?>
				const markerContent = '<?= esc_js($marker_content) ?>';
				L.marker( [ <?= $attributes["lat"] ?>, <?= $attributes["lng"] ?> ], { icon } )
					.addTo( map )
					.bindPopup( markerContent.replace( /\r?\n/g, '<br />' ) );
				<?php } else { ?>
				L.marker( [ <?= $attributes["lat"] ?>, <?= $attributes[
    "lng"
] ?> ], { icon } ).addTo( map );
				<?php } ?>

				const container = document.getElementById( '<?= $id ?>' );
				const observer  = ResizeObserver && new ResizeObserver( function() {
					map.invalidateSize( true );
				} );

				observer && observer.observe( container );
			}

			document.addEventListener( 'DOMContentLoaded', initilize );
		} )();
	</script>
</div>
