<?php
/**
 * Server-side render for wp-swiper/hero-slider.
 *
 * @var array    $attributes Block attributes.
 * @var string   $content    Block default content.
 * @var WP_Block $block      Block instance.
 */

$slides         = $attributes['slides'] ?? [];
$slider_height  = intval( $attributes['sliderHeight'] ?? 560 );
$autoplay       = (bool) ( $attributes['autoplay'] ?? true );
$autoplay_delay = intval( $attributes['autoplayDelay'] ?? 5000 );
$loop           = (bool) ( $attributes['loop'] ?? true );
$speed          = intval( $attributes['speed'] ?? 800 );
$overlay_color  = sanitize_hex_color( $attributes['overlayColor'] ?? '#b5c9db' );
$overlay_opacity = intval( $attributes['overlayOpacity'] ?? 75 );
$card_position  = in_array( $attributes['cardPosition'] ?? 'left', [ 'left', 'center', 'right' ], true )
	? $attributes['cardPosition']
	: 'left';
$card_max_width = intval( $attributes['cardMaxWidth'] ?? 550 );
$card_padding   = intval( $attributes['cardPadding'] ?? 50 );
$accent_color   = sanitize_hex_color( $attributes['accentColor'] ?? '#0076a3' );
$dark_color     = sanitize_hex_color( $attributes['darkColor'] ?? '#0b2240' );
$text_color     = sanitize_hex_color( $attributes['textColor'] ?? '#4a5568' );
$show_arrows    = (bool) ( $attributes['showArrows'] ?? true );
$show_pagination = (bool) ( $attributes['showPagination'] ?? true );

if ( empty( $slides ) ) {
	return;
}

// Convert hex overlay color to rgb for opacity support.
$hex = ltrim( $overlay_color, '#' );
$r   = hexdec( substr( $hex, 0, 2 ) );
$g   = hexdec( substr( $hex, 2, 2 ) );
$b   = hexdec( substr( $hex, 4, 2 ) );
$overlay_rgba = "rgba({$r},{$g},{$b}," . ( $overlay_opacity / 100 ) . ')';

$unique_id = 'wps-' . wp_unique_id();

$justify_map = [
	'left'   => 'flex-start',
	'center' => 'center',
	'right'  => 'flex-end',
];
$justify = $justify_map[ $card_position ] ?? 'flex-start';

$block_attrs = get_block_wrapper_attributes( [
	'class'            => 'wp-swiper-hero-slider',
	'data-autoplay'    => $autoplay ? 'true' : 'false',
	'data-delay'       => (string) $autoplay_delay,
	'data-loop'        => $loop ? 'true' : 'false',
	'data-speed'       => (string) $speed,
] );

$css_vars = sprintf(
	'--wps-height:%dpx;--wps-overlay:%s;--wps-card-max-width:%dpx;--wps-card-padding:%dpx;--wps-justify:%s;--wps-accent:%s;--wps-dark:%s;--wps-text:%s;',
	$slider_height,
	$overlay_rgba,
	$card_max_width,
	$card_padding,
	$justify,
	$accent_color,
	$dark_color,
	$text_color
);
?>
<div <?php echo $block_attrs; ?>>
	<div class="wp-swiper-hero-slider__inner" style="<?php echo esc_attr( $css_vars ); ?>">
		<div class="swiper <?php echo esc_attr( $unique_id ); ?>">
			<div class="swiper-wrapper">
				<?php foreach ( $slides as $slide ) :
					$bg_url     = esc_url( $slide['backgroundUrl'] ?? '' );
					$badge      = sanitize_text_field( $slide['badge'] ?? '' );
					$title      = sanitize_text_field( $slide['title'] ?? '' );
					$description = sanitize_text_field( $slide['description'] ?? '' );
					$link_text  = sanitize_text_field( $slide['linkText'] ?? 'Learn more' );
					$link_url   = esc_url( $slide['linkUrl'] ?? '#' );
				?>
				<div class="swiper-slide"<?php if ( $bg_url ) : ?> style="background-image:url('<?php echo $bg_url; ?>')"<?php endif; ?>>
					<div class="wps-card">
						<?php if ( $badge ) : ?>
							<span class="wps-badge"><?php echo esc_html( $badge ); ?></span>
						<?php endif; ?>
						<?php if ( $title ) : ?>
							<h2 class="wps-title"><?php echo esc_html( $title ); ?></h2>
						<?php endif; ?>
						<?php if ( $description ) : ?>
							<p class="wps-description"><?php echo esc_html( $description ); ?></p>
						<?php endif; ?>
						<?php if ( $link_url && $link_text ) : ?>
							<a href="<?php echo $link_url; ?>" class="wps-link">
								<?php echo esc_html( $link_text ); ?>
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
									<line x1="5" y1="12" x2="19" y2="12"/>
									<polyline points="12 5 19 12 12 19"/>
								</svg>
							</a>
						<?php endif; ?>
					</div>
				</div>
				<?php endforeach; ?>
			</div>

			<div class="wps-controls">
				<?php if ( $show_arrows ) : ?>
					<div class="swiper-button-prev"></div>
				<?php endif; ?>
				<?php if ( $show_pagination ) : ?>
					<div class="swiper-pagination"></div>
				<?php endif; ?>
				<?php if ( $show_arrows ) : ?>
					<div class="swiper-button-next"></div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
