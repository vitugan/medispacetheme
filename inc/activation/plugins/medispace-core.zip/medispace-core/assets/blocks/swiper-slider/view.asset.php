<?php return array('dependencies' => array(), 'version' => 'a152033ff4bf472d2411');
