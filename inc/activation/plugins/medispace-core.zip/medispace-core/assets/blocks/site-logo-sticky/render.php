<?php
/**
 * PHP file to render the site-logo-sticky block.
 * Welds both the default core site logo and the custom sticky logo
 * into a single wrapper. Falls back to Site Title if no logos are set.
 *
 * @package MediSpaceCore
 */

$blog_id = get_current_blog_id();
$html = "";

$default_logo_id = get_theme_mod("custom_logo");

$sticky_logo_id = get_theme_mod("msc_sticky_logo_id");
$sticky_width = get_theme_mod("msc_sticky_logo_width", 128);

$variable_style = sprintf(
    ' style="--msc-sticky-logo-width: %1$spx;"',
    absint($sticky_width),
);

if ($default_logo_id || $sticky_logo_id) {
    $images_html = "";

    if ($default_logo_id) {
        $default_logo_attr = [
            "class" => "custom-logo logo-dark", // Клас для стилізації прозорого стану
            "loading" => false,
            "style" => "max-width:" . absint($sticky_width) . "px;",
        ];

        $image_alt = get_post_meta(
            $default_logo_id,
            "_wp_attachment_image_alt",
            true,
        );
        if (empty($image_alt)) {
            $default_logo_attr["alt"] = get_bloginfo("name", "display");
        }

        $default_logo_attr = apply_filters(
            "get_custom_logo_image_attributes",
            $default_logo_attr,
            $default_logo_id,
            $blog_id,
        );
        $images_html .= wp_get_attachment_image(
            $default_logo_id,
            "full",
            false,
            $default_logo_attr,
        );
    } else {
        $images_html .= sprintf(
            '<span class="site-title-text logo-dark">%1$s</span>',
            esc_html(get_bloginfo("name")),
        );
    }

    if ($sticky_logo_id) {
        $sticky_logo_attr = [
            "class" => "custom-logo logo-light",
            "loading" => false,
            "style" => "max-width:" . absint($sticky_width) . "px;",
        ];

        $sticky_alt = get_post_meta(
            $sticky_logo_id,
            "_wp_attachment_image_alt",
            true,
        );
        if (empty($sticky_alt)) {
            $sticky_logo_attr["alt"] =
                get_bloginfo("name", "display") . " Sticky";
        }

        $sticky_logo_attr = apply_filters(
            "get_custom_logo_image_attributes",
            $sticky_logo_attr,
            $sticky_logo_id,
            $blog_id,
        );
        $images_html .= wp_get_attachment_image(
            $sticky_logo_id,
            "full",
            false,
            $sticky_logo_attr,
        );
    } else {
        $images_html .= sprintf(
            '<span class="site-title-text logo-light">%1$s</span>',
            esc_html(get_bloginfo("name")),
        );
    }

    if (is_front_page() && !is_paged()) {
        $html = sprintf(
            '<span class="custom-logo-link sticky-logo-wrapper">%1$s</span>',
            $images_html,
        );
    } else {
        $aria_current =
            is_front_page() && !is_paged() ? ' aria-current="page"' : "";
        $html = sprintf(
            '<a href="%1$s" class="custom-logo-link sticky-logo-wrapper" rel="home"%2$s>%3$s</a>',
            esc_url(home_url("/")),
            $aria_current,
            $images_html,
        );
    }
} else {
    $site_title = esc_html(get_bloginfo("name"));

    if (is_front_page() && !is_paged()) {
        $html = sprintf(
            '<span class="custom-logo-link sticky-logo-wrapper"%1$s>%2$s</span>',
            $variable_style,
            $images_html,
        );
    } else {
        $aria_current =
            is_front_page() && !is_paged() ? ' aria-current="page"' : "";
        $html = sprintf(
            '<a href="%1$s" class="custom-logo-link sticky-logo-wrapper" rel="home"%2$s%3$s>%4$s</a>',
            esc_url(home_url("/")),
            $aria_current,
            $variable_style,
            $images_html,
        );
    }
}

echo $html;
