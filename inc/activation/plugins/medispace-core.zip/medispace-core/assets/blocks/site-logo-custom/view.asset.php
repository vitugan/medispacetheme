<?php return array('dependencies' => array(), 'version' => '908809480032ff8e01f9');
