<?php
/**
 * PHP file to use when rendering the block type on the server to show on the front end.
 *
 * The following variables are exposed to the file:
 *     $attributes (array): The block attributes.
 *     $content (string): The block default content.
 *     $block (WP_Block): The block instance.
 *
 * @see https://github.com/WordPress/gutenberg/blob/trunk/docs/reference-guides/block-api/block-metadata.md#render
 */


$blog_id	= get_current_blog_id();
$html = '';


$custom_logo_id = get_theme_mod( 'msc_custom_logo_id' );

// We have a logo. Logo is go.
if ( $custom_logo_id ) {
	$custom_logo_attr = array(
		'class'   => 'custom-logo',
		'loading' => false,
	);

	$image_alt = get_post_meta( $custom_logo_id, '_wp_attachment_image_alt', true );
	if ( empty( $image_alt ) ) {
		$custom_logo_attr['alt'] = get_bloginfo( 'name', 'display' );
	}

	$custom_logo_attr = apply_filters( 'get_custom_logo_image_attributes', $custom_logo_attr, $custom_logo_id, $blog_id );
	
	$image = wp_get_attachment_image( $custom_logo_id, 'full', false, $custom_logo_attr );

	if ( is_front_page() && ! is_paged() ) {
		// If on the home page, don't link the logo to home.
		$html = sprintf(
			'<span class="custom-logo-link">%1$s</span>',
			$image
		);
	} else {
		$aria_current = is_front_page() && ! is_paged() ? ' aria-current="page"' : '';

		$html = sprintf(
			'<a href="%1$s" class="custom-logo-link" rel="home"%2$s>%3$s</a>',
			esc_url( home_url( '/' ) ),
			$aria_current,
			$image
		);
	}
} elseif ( is_customize_preview() ) {
	// If no logo is set but we're in the Customizer, leave a placeholder (needed for the live preview).
	$html = sprintf(
		'<a href="%1$s" class="custom-logo-link" style="display:none;"><img class="custom-logo" alt="" /></a>',
		esc_url( home_url( '/' ) )
	);
}

echo $html;